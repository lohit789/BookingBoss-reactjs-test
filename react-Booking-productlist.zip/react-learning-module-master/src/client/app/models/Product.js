class Product {
  constructor(json) {
    this.self = json;
  }
} 

export default Product;